<?php
    /**
     * Your Twitter App Info
     */
    
    // Consumer Key
    define('CONSUMER_KEY', 'prENs8a6IFI1sluNxfTYvBIik');
    define('CONSUMER_SECRET', '0X4xgFooMEvW6JYkNJJQbQPjh532dHgXFFXOnbvwHfhSU9nk6D');

    // User Access Token
    define('ACCESS_TOKEN', '445548426-cyGB23M6X4APyweKfoyGNNF3L3DyxZ6hbDOeLA4H');
    define('ACCESS_SECRET', '57QI6Vie5OWU5PWlreGLeDMQam5Pp4j28RILbnhX9jAoD');
	
	// Cache Settings
	define('CACHE_ENABLED', false);
	define('CACHE_LIFETIME', 3600); // in seconds
	define('HASH_SALT', md5(dirname(__FILE__)));