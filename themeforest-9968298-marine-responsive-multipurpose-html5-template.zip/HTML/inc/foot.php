
	
	</div>
	<!-- /Marine Content Wrapper -->
	
	
	<!-- JavaScript -->
	<script type='text/javascript' src='js/bootstrap.min.js'></script>
	<script type='text/javascript' src='js/jquery-ui.min.js'></script>
	<script type='text/javascript' src='js/jquery.easing.1.3.js'></script>
	<script type='text/javascript' src='js/jquery.mousewheel.min.js'></script>
	<script type='text/javascript' src='js/SmoothScroll.min.js'></script>
	<script type='text/javascript' src='js/prettyphoto/js/jquery.prettyPhoto.js'></script>
	<script type='text/javascript' src='js/modernizr.js'></script>
	<script type='text/javascript' src='js/wow.min.js'></script>
	<script type='text/javascript' src='js/jquery.sharre.min.js'></script>
	<script type='text/javascript' src='js/jquery.flexslider-min.js'></script>
	<script type='text/javascript' src='js/jquery.knob.js'></script>
	<script type='text/javascript' src='js/jquery.mixitup.min.js'></script>
	<script type='text/javascript' src='js/masonry.min.js?ver=3.1.2'></script>
	<script type='text/javascript' src='js/jquery.masonry.min.js?ver=3.1.2'></script>
	<script type='text/javascript' src='js/jquery.fitvids.js'></script>
	<script type='text/javascript' src='js/perfect-scrollbar-0.4.10.with-mousewheel.min.js'></script>
	<script type='text/javascript' src='js/jquery.nouislider.min.js'></script>
	<script type='text/javascript' src='js/jquery.validity.min.js'></script>
	<script type='text/javascript' src='js/script.js'></script>
		
	</body>
	
</html>