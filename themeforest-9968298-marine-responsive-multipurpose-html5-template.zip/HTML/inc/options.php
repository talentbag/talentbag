<?php

/**
 *	Filename: options.php
 *
 *	Contains all default options for template
 */

$marine = array(
	
	/**
	 *	Page Info Options
	 */
	
	// Page Title
	'title' => '', 
	
	// Page Meta Description
	'description' => '', 
	
	// Page Meta Keywords
	'keywords' => ''
	
	
);


?>