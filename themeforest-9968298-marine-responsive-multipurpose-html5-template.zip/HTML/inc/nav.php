
							<div class="menu">
								<ul>
									<li><a href="index.php">Home</a>
										<ul>
											<li><a href="#">Home Version One</a></li>
											<li><a href="#">Home Basic</a></li>
											<li><a href="#">Home Portfolio</a>
												<ul>
													<li><a href="#">Home Version One</a></li>
													<li><a href="#">Home Basic</a></li>
													<li><a href="#">Home Portfolio</a></li>
													<li><a href="#">Home Vertical</a></li>
													<li><a href="#">Home One Page</a></li>
													<li><a href="#">Home Version Purple</a></li>
												</ul>
											</li>
											<li><a href="#">Home Vertical</a></li>
											<li><a href="#">Home One Page</a></li>
											<li><a href="#">Home Version Purple</a></li>
										</ul>
									</li>
									<li><a href="index.php">Features</a>
										<ul>
											<li><a href="sc-page-one.php">Shortcodes 1</a></li>
											<li><a href="sc-page-two.php">Shortcodes 2</a></li>
											<li><a href="sc-counters.php">Counters</a></li>
											<li><a href="sc-pricing-tables.php">Pricing Tables</a></li>
											<li><a href="sc-testimonials.php">Testimonials</a></li>
											<li><a href="sc-promo-boxes.php">Promo Boxes</a></li>
											<li><a href="sc-content-boxes.php">Content Boxes</a></li>
											<li><a href="sc-typography.php">Typography</a></li>
										</ul>
									</li>
									<li><a href="index.php">Headers</a>
										<ul>
											<li><a href="#">Normal</a>
												<ul>
													<li><a href="headers-1.php">Default</a></li>
													<li><a href="headers-1.php?main_hbg=bittersweet&amp;main_hcl=light&amp;nav_cl=white&amp;nav_active_cl=white&amp;nav_active_br=bittersweet&amp;nav_opacity=true&amp;logo=white">Bitersweet</a></li>
													<li><a href="headers-1.php?main_hbg=green&amp;main_hcl=light&amp;nav_active_cl=white&amp;logo=white">Green</a></li>
													<li><a href="headers-1.php?main_hbg=dark-blue&amp;main_hcl=light&amp;nav_active_cl=white&amp;logo=light">Dark Blue</a></li>
													<li><a href="headers-1.php?main_hbg=light-blue&amp;main_hcl=light&amp;nav_active_cl=white&amp;logo=white">Light Blue</a></li>
													<li><a href="headers-1.php?main_hbg=blue&amp;main_hcl=light&amp;nav_active_cl=white&amp;nav_active_br=white&amp;logo=white">Blue</a></li>
												</ul>
											</li>
											<li><a href="headers-2.php">With Preheader 1</a></li>
											<li><a href="#">With Preheader 2</a>
												<ul>
													<li><a href="headers-3.php?pre_hbg=blue&amp;pre_hcl=light&amp;nav_active_br=white">Default</a></li>
													<li><a href="headers-3.php?main_hbg=black&amp;main_hcl=light&amp;pre_hbg=blue&amp;pre_hcl=light&amp;nav_active_br=black&amp;logo=light">Black</a></li>
													<li><a href="headers-3.php?main_hbg=blue&amp;main_hcl=light&amp;pre_hbg=black&amp;pre_hcl=light&amp;nav_active_cl=white&amp;nav_active_br=blue&amp;logo=light">Blue</a></li>
												</ul>
											</li>
											<li><a href="#">With Lower Header</a>
												<ul>
													<li><a href="headers-4.php?main_hbg=blue&amp;main_hcl=light&amp;logo=white">Blue</a></li>
													<li><a href="headers-4.php?main_hbg=dark-blue&amp;main_hcl=light&amp;logo=light">Dark Blue</a></li>
												</ul>
											</li>
											<li><a href="headers-5.php?pre_hbg=blue&amp;pre_hcl=light&amp;nav_active_br=white">With Preheader &amp; Lower Header</a></li>
											<li><a href="#">Transparent</a></li>
											<li><a href="#">Sideheader 1</a></li>
											<li><a href="#">Sideheader 2</a></li>
										</ul>
									</li>
									<li><a href="index.php">Portfolio</a></li>
									<li><a href="index.php">Blog</a></li>
									<li><a href="index.php">Shop</a></li>
									<li><a href="index.php">Contact</a></li>
								</ul>
							</div>